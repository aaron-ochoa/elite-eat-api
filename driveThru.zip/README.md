Finnder API
API that serves the Finnder app
Running the API
Use Docker. Run docker-compose up

Endpoints
GET /api/v1/restaurants
Endpoints accepts query parameters: size as integer 0-any. Endpoint returns

location
restaurant name
list of images
